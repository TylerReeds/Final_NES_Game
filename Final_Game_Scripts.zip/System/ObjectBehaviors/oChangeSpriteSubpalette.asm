oChangeSpriteSubpalette

	RTS