oChangeSubpalette:

	RTS