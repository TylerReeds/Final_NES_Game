oCheckLocalVariable:

	RTS
	