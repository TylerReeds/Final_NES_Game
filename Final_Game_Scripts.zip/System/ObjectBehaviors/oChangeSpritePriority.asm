oChangeSpritePriority:

	RTS