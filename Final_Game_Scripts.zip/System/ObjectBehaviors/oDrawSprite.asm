oDrawSprite:

	RTS