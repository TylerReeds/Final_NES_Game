
oSetLocalVariable:

	RTS