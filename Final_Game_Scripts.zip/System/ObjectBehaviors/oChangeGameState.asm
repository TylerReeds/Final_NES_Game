oChangeGameState:

	RTS