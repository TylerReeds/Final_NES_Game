oStopAllSounds:

	RTS