oReverseDirection:

	RTS