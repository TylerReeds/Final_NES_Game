oCheckGlobalVariable

	RTS