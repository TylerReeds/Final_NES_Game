oPlayMusic:

	RTS
