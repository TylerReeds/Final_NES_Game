oDestroySelectedObject:

	RTS
