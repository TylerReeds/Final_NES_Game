oFlipAiBits:

	RTS