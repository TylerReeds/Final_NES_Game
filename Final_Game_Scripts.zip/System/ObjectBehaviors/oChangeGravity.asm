oChangeGravity:

	RTS