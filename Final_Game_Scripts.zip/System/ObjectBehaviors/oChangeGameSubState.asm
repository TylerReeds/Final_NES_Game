oChangeGameSubState:

	RTS