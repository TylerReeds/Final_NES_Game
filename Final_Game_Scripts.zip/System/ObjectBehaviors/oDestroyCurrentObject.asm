oDestroyCurrentObject:

	RTS