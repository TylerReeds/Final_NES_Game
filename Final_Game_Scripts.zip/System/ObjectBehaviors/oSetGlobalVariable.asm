	
oSetGlobalVariable:

	RTS