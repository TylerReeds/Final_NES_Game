oCreateObjectAtPosition:

	RTS