oUpdateHud:

	RTS