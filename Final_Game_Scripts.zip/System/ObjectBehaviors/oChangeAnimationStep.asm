oChangeAnimationStep:

	RTS