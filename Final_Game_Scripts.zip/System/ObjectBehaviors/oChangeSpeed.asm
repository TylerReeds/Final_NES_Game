oChangeSpeed:

	RTS