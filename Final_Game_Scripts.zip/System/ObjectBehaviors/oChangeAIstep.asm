oChangeAIstep:

	RTS
	