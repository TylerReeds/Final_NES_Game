NMI:
;; Blank NMI

	
	RTI