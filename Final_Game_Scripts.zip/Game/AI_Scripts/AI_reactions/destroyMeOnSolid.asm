;;;; destroy this object 
	DestroyObject