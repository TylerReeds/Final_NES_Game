doHandleHurtPlayer:
	JMP RESET
	RTS