updateAction:	
	
	RTS