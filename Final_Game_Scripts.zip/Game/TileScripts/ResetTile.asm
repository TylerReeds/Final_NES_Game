;;; Simple Reset
	JMP RESET