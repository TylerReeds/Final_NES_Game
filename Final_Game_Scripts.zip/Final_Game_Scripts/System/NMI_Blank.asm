NMI:
;; Blank NMI

	
	RTI