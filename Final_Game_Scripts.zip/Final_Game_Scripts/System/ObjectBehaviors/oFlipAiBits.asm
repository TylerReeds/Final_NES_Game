oFlipAiBits:

	RTS