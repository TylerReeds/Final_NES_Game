oChangeGravity:

	RTS