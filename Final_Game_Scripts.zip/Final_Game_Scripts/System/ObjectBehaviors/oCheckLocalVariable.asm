oCheckLocalVariable:

	RTS
	