oChangeSubpalette:

	RTS