	
oSetGlobalVariable:

	RTS