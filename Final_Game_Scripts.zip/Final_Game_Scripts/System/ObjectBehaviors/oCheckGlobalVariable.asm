oCheckGlobalVariable

	RTS