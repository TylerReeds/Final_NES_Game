oUpdateHud:

	RTS