oChangeAIstep:

	RTS
	