oPlayMusic:

	RTS
