oDestroyCurrentObject:

	RTS