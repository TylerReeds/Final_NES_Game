oChangeSpritePriority:

	RTS