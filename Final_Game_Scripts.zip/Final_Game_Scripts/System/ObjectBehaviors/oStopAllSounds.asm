oStopAllSounds:

	RTS