oCreateObjectAtPosition:

	RTS