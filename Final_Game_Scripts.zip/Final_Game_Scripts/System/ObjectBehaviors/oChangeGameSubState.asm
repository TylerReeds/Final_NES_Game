oChangeGameSubState:

	RTS