oDestroySelectedObject:

	RTS
