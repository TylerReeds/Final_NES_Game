oDrawSprite:

	RTS