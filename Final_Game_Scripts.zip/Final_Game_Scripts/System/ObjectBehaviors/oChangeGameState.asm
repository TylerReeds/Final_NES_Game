oChangeGameState:

	RTS