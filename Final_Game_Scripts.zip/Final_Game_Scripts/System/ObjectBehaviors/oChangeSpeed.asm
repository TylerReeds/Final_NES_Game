oChangeSpeed:

	RTS