
oSetLocalVariable:

	RTS