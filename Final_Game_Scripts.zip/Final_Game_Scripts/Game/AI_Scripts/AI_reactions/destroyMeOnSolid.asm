;;;; destroy this object 
	DestroyObject