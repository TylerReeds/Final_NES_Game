updateAction:	
	
	RTS