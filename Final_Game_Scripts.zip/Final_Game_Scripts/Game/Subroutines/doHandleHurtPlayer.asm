doHandleHurtPlayer:
	JMP RESET
	RTS