;;; Simple Reset
	JMP RESET